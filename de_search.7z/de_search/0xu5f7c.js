DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5f7c"] = [
	{ "s": "彼此分享新聞並交換警示", "p": [11] }
];