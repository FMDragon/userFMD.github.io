DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u96b8"] = [
	{ "s": "隸屬這一領域的牧師們認為", "p": [11] }
];