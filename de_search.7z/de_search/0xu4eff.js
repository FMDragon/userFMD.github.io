DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4eff"] = [
	{ "s": "仿效獵人範型意味着接受你作爲文明和荒野恐懼間壁壘的身分", "p": [11] },
	{ "s": "仿效獸王範型意味着將自己奉獻給這個理念", "p": [11] }
];