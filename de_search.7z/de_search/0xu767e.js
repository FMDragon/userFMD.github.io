DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u767e"] = [
	{ "s": "百年前", "p": [3] },
	{ "s": "百年前，王國以繁榮、軍力與文化享譽大陸，曾被譽為「月下之國」，是人類文明的巔峰。然而，內憂與外患如同交織的荊棘，逐漸將這片土地拖入深淵。貴族內鬥、王族腐敗、軍士的士氣低落，讓外敵的侵略成為壓垮這個王國的最後一擊", "p": [3] }
];