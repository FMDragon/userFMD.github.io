DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u539f"] = [
	{ "s": "原因有待探索", "p": [6] },
	{ "s": "原本以為可以找回很多烈士的英魂", "p": [5] }
];