DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6559"] = [
	{ "s": "教團騎士", "p": [9] },
	{ "s": "教堂的核心是中央大廳", "p": [5] },
	{ "s": "教堂的核心是中央大廳，這裡空間開闊，高聳的圓頂由繁複的拱梁支撐，陽光透過彩繪玻璃灑落，彷彿為亡靈們的歸來而設計。中央矗立著藍焰祭壇", "p": [5] },
	{ "s": "教導人們把藝術作爲提升靈魂層次的工具", "p": [11] }
];