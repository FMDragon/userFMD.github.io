DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6c34"] = [
	{ "s": "水元素位面或者其他的異界海洋的無盡力量", "p": [11] },
	{ "s": "水手", "p": [9] },
	{ "s": "水手浪客以及在無垠的地平線上尋求刺激的遊蕩的守護者", "p": [11] }
];