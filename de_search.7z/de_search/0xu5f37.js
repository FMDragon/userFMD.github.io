DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5f37"] = [
	{ "s": "強壯到能讓你騎乘", "p": [11] },
	{ "s": "強大的魔劍", "p": [11] },
	{ "s": "強烈的情感", "p": [11] },
	{ "s": "強盜", "p": [11] },
	{ "s": "強魄半身人", "p": [10] }
];