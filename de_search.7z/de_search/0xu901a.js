DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u901a"] = [
	{ "s": "通常出身貴族", "p": [11] },
	{ "s": "通過古老的儀式", "p": [4] },
	{ "s": "通過廣泛的口述傳承來守護古老知識和儀式", "p": [11] },
	{ "s": "通過我們處在的現實", "p": [11] },
	{ "s": "通過揭示並理解羣星之奧妙", "p": [11] },
	{ "s": "通過歌曲", "p": [11] },
	{ "s": "通道深處偶爾閃過不明的影子", "p": [6] }
];