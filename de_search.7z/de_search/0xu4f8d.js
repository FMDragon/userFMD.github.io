DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f8d"] = [
	{ "s": "侍僧", "p": [9] },
	{ "s": "侍僧：你被那些與你有共同信仰的人們所尊敬，且你可以舉行你信仰的宗教儀式。你與你的冒險夥伴可以在寺廟、神殿、或其他屬於你宗教的官方機構中獲得免費的治療與照護，但是你仍必須提供任何法術所需的構材", "p": [9] }
];