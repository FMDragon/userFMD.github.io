DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\uff13"] = [
	{ "s": "３００ＧＰ以下", "p": [7] }
];