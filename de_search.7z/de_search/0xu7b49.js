DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7b49"] = [
	{ "s": "等待着被以任何方式釋放出來", "p": [11] }
];