DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5929"] = [
	{ "s": "天界", "p": [11] },
	{ "s": "天界：你的宗主是一個上層位面的強大存在。你和一位古老的至高天、熾天神侍、麒麟、獨角獸、或其他居住於那永樂位面中的存在締結了契約。你與該存在之間的契約讓你得以經歷到那照亮多元宇宙的聖光最直接的觸碰", "p": [11] },
	{ "s": "天空終日陰沉", "p": [3] }
];