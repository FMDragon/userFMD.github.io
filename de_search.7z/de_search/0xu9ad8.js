DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9ad8"] = [
	{ "s": "高等精靈", "p": [10] },
	{ "s": "高聳的圓頂由繁複的拱梁支撐", "p": [5] }
];