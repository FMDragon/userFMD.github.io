DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u70ae"] = [
	{ "s": "炮彈和爆炸物的專家", "p": [11] }
];