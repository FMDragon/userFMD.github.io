DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u91d1"] = [
	{ "s": "金", "p": [10] },
	{ "s": "金屬龍裔", "p": [10] },
	{ "s": "金屬龍裔【金、銀、青銅、黃銅、赤銅", "p": [10] }
];