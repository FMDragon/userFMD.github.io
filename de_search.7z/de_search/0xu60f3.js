DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u60f3"] = [
	{ "s": "想想法師爲研讀卷宗與書寫魔法理論花費了多少時間", "p": [11] }
];