DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6cf0"] = [
	{ "s": "泰爾達茲的滅亡真相", "p": [6] }
];