DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5206"] = [
	{ "s": "分享新聞", "p": [11] },
	{ "s": "分享褻瀆生命的知識和祕密", "p": [11] }
];