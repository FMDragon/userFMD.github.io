DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f4d"] = [
	{ "s": "位置與外觀", "p": [5] },
	{ "s": "位置與規模", "p": [5] }
];