DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5ff5"] = [
	{ "s": "念力鞭撻和靈能屏障來強化自己肉體力量的戰士", "p": [11] }
];