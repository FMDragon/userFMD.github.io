DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5426"] = [
	{ "s": "否則他們絕不會殺死自己的敵人", "p": [11] }
];