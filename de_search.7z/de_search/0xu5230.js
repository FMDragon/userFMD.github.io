DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5230"] = [
	{ "s": "到他們對君王的忠誠", "p": [11] },
	{ "s": "到巨人和恐怖的龍族們", "p": [11] },
	{ "s": "到製作過曾擊敗惡魔領主的鑽石尖祕銀箭的強大精靈工匠", "p": [11] }
];