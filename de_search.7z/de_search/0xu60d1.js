DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u60d1"] = [
	{ "s": "惑控", "p": [11] },
	{ "s": "惑控：作爲惑控學派的成員，你磨練你的能力於藉由魔法迷惑並欺騙其他人和怪物。一部份的惑控師是和平主義者，致力於蠱惑暴力者使之放下武器，並魅惑殘忍者使之展現慈悲。另一些惑控師則是暴君，利用魔法強迫不情願的人們爲他工作。而絕大多數的惑控師則介於兩者之間", "p": [11] }
];