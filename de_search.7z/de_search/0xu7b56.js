DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7b56"] = [
	{ "s": "策士", "p": [11] },
	{ "s": "策士專注於人們", "p": [11] },
	{ "s": "策士：策士專注於人們、對人們的影響力、以及他們所擁有的祕密。許多間諜、朝臣、和陰謀家會遵從這個範型，過着勾心鬥角的生活。你使用言語作爲你的武器，就如同使用刀刃和毒藥一樣頻繁，而人們的祕密和支持則是你最喜愛的寶藏之一", "p": [11] }
];