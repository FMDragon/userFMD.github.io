DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u76f8"] = [
	{ "s": "相反", "p": [11] },
	{ "s": "相較其他戰士就像是被鋼鐵重甲包覆的粗人", "p": [11] }
];