DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u95c7"] = [
	{ "s": "闇月茹蒂斯被人視為敬畏和憂懼的標誌", "p": [11] }
];