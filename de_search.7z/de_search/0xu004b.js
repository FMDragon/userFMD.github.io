DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u004b"] = [
	{ "s": "KEYWORD", "p": [8, 2] },
	{ "s": "KÄMPFEN", "p": [1] }
];