DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5931"] = [
	{ "s": "失落的圖書館", "p": [6, 5] },
	{ "s": "失落的圖書館隱藏在規源的偏僻一翼", "p": [5] },
	{ "s": "失落的圖書館隱藏在規源的偏僻一翼，巨大的石門上刻滿了符文與模糊的文字。外牆佈滿蔓藤，石牆在昏暗中散發著微弱的光，彷彿在引誘知識的探索者", "p": [5] }
];