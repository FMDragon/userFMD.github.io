DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5b78"] = [
	{ "s": "學習惑控和幻術系的詭術", "p": [11] },
	{ "s": "學者", "p": [9] }
];