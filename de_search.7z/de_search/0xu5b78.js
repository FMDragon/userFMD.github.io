DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5b78"] = [
	{ "s": "學習惑控和幻術系的詭術", "p": [11] },
	{ "s": "學者", "p": [9] },
	{ "s": "學者：當你嘗試學習或回想一段知識時，如果你不知道這個知識的情報，你通常仍能知道該從哪裏或哪個人那邊得到它", "p": [9] }
];