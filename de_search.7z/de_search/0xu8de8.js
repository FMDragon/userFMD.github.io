DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8de8"] = [
	{ "s": "跨過死亡之門有着切身體會", "p": [11] }
];