DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7b54"] = [
	{ "s": "答案會根據你們的一步步探索逐漸解開", "p": [13] }
];