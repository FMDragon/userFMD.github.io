DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u92d2"] = [
	{ "s": "鋒刃", "p": [11] },
	{ "s": "鋒刃們的演出體操包括吞劍", "p": [11] }
];