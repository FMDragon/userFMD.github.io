DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6728"] = [
	{ "s": "木精靈", "p": [10] },
	{ "s": "木精靈血統", "p": [10] }
];