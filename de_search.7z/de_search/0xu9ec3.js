DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9ec3"] = [
	{ "s": "黃玉", "p": [10] },
	{ "s": "黃銅", "p": [10] }
];