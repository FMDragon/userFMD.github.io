DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u85cd"] = [
	{ "s": "藍焰祭壇", "p": [5] },
	{ "s": "藍焰祭壇不僅是亡靈復甦的地方", "p": [5] },
	{ "s": "藍焰祭壇不僅是亡靈復甦的地方，還是所有儀式的核心，牽魂人每次召喚新靈魂時，大廳會響起低沉的共鳴，猶如亡者的低語", "p": [5] }
];