DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u69cb"] = [
	{ "s": "構成宇宙的其中一種基本力量", "p": [11] }
];