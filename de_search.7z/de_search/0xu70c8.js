DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u70c8"] = [
	{ "s": "烈士們在這裡交流或進行集體活動", "p": [5] }
];