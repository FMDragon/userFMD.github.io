DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u89c0"] = [
	{ "s": "觀衆們將可能會發現自己對所有深信不疑的事情提出質疑", "p": [11] }
];