DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u50f1"] = [
	{ "s": "僱傭殺手", "p": [11] }
];