DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9bae"] = [
	{ "s": "鮮血", "p": [11] },
	{ "s": "鮮血領域由荒洲的猩紅結社開發", "p": [11] },
	{ "s": "鮮血：鮮血領域由荒洲的猩紅結社開發，他們注重於理解存在於體內的生命天生具有的力量，並將其拓展為傳輸神聖力量的通道。隸屬這一領域的牧師們認為，血的力量是犧牲的力量，是生與死的平衡，是精魂在身軀中的錨點", "p": [11] }
];