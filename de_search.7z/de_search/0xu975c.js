DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u975c"] = [
	{ "s": "靜靜矗立在王國滅亡的廢墟中", "p": [5] }
];