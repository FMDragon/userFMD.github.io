DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5353"] = [
	{ "s": "卓爾精靈", "p": [10] },
	{ "s": "卓爾精靈血統", "p": [10] }
];