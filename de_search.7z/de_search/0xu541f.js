DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u541f"] = [
	{ "s": "吟唱着關於過去和現在的偉大事蹟", "p": [11] },
	{ "s": "吟遊詩人", "p": [11] },
	{ "s": "吟遊詩人相信這個宇宙是一個藝術作品", "p": [11] }
];