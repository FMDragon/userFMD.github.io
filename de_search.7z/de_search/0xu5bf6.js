DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5bf6"] = [
	{ "s": "寶石龍裔", "p": [10] },
	{ "s": "寶石龍裔【紫晶、水晶、翡翠、藍寶石、黃玉", "p": [10] }
];