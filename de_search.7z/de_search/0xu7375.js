DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7375"] = [
	{ "s": "獵人", "p": [11] },
	{ "s": "獵人：仿效獵人範型意味着接受你作爲文明和荒野恐懼間壁壘的身分。隨着你行走在獵人的道途上，你學會對抗迎面而來威脅的專業技巧，從狂暴的食人魔、成羣的獸人、到巨人和恐怖的龍族們", "p": [11] }
];