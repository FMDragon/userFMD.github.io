DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8a18"] = [
	{ "s": "記住", "p": [6] },
	{ "s": "記住，圖書館是為了幫助你，而不是為了吞噬你", "p": [6] },
	{ "s": "記錄", "p": [11] }
];