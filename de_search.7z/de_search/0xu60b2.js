DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u60b2"] = [
	{ "s": "悲劇", "p": [11] },
	{ "s": "悲劇：並非所有偉大的故事都有圓滿的結局。許多故事以死亡和絕望告終，而悲劇學院的吟遊詩人知曉，哀傷和悲愴是和歡樂喜悅相同的強大情感。這些詩人擅長講述悲劇故事，他們將台詞和法術編織在一起，造成兼具戲劇性和毀滅性的效果", "p": [11] }
];