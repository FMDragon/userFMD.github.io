DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u50b3"] = [
	{ "s": "傳說中", "p": [3] },
	{ "s": "傳說中，王國滅亡前秘密啟動了一項計畫，名為「規源」，意圖以古老的力量保留王國的希望。然而，這項計畫的真相早已被埋沒在歷史與謠言之中。冒險者們相信，規源的秘密可能藏於廢墟中的某個密室，或者荒野深處的某片禁地", "p": [3] },
	{ "s": "傳說有言以此相開山立派", "p": [11] }
];