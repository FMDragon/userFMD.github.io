DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6614"] = [
	{ "s": "昔日的城池成為無人居住的廢墟", "p": [3] }
];