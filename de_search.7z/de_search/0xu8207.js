DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8207"] = [
	{ "s": "與不死之間的宇宙力量", "p": [11] },
	{ "s": "與他們相反", "p": [11] },
	{ "s": "與動物作爲同伴和朋友一同奮鬥", "p": [11] },
	{ "s": "與圖書館的互動", "p": [6] },
	{ "s": "與它所擁有的無盡祕密相比", "p": [11] },
	{ "s": "與物質位面的本質於精神上連結", "p": [11] },
	{ "s": "與野蠻人和遊俠同行", "p": [11] }
];