DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8a66"] = [
	{ "s": "試圖在威脅來到廣闊世界之前伏擊它們", "p": [11] }
];