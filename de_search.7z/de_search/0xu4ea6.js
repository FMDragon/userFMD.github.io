DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4ea6"] = [
	{ "s": "亦或企圖尋找失落的寶藏與古老的真相", "p": [3] }
];