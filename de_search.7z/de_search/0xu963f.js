DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u963f"] = [
	{ "s": "阿斯莫和元素裔的野蠻人中不乏選擇狂野魔法道途的", "p": [11] },
	{ "s": "阿斯蒙蒂斯之血", "p": [10] }
];