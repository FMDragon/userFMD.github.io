DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5b62"] = [
	{ "s": "孢子", "p": [11] },
	{ "s": "孢子結社的德魯伊們能在腐朽中發現美", "p": [11] },
	{ "s": "孢子：孢子結社的德魯伊們能在腐朽中發現美。他們在黴菌和其他真菌中發現，那能將無生命物質轉變成儘管有些奇怪，卻有着豐富生命的能力", "p": [11] }
];