DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u505a"] = [
	{ "s": "做出植根於現實而非理想的嚴峻抉擇", "p": [11] },
	{ "s": "做好抗未來邪惡的準備", "p": [11] }
];