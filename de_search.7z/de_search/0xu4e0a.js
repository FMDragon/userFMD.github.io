DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4e0a"] = [
	{ "s": "上層位面", "p": [11] },
	{ "s": "上面堆滿布包的糧食與器具", "p": [5] }
];