DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53ef"] = [
	{ "s": "可以帶知識回圖書館", "p": [6] },
	{ "s": "可以帶知識回圖書館，圖書館會很開心，但如果圖書館知道太多", "p": [6] },
	{ "s": "可能是烈士也可能是罪犯", "p": [7] }
];