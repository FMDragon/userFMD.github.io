DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u58eb"] = [
	{ "s": "士兵", "p": [9] },
	{ "s": "士兵：你擁有一個來自你軍人生涯的軍階。其他效忠於你軍事組織的士兵仍然會承認你的地位和影響力，軍階比你低的士兵甚至會服從你的指示", "p": [9] }
];