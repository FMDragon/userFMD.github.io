DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u76f4"] = [
	{ "s": "直到他們自身都變得如同幽靈一般", "p": [11] },
	{ "s": "直到偶然遭遇另一個類人生物", "p": [11] }
];