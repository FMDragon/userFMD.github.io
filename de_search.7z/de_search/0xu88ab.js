DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u88ab"] = [
	{ "s": "被他們神明的光輝和洞察力給充滿", "p": [11] },
	{ "s": "被污濁的自然", "p": [11] },
	{ "s": "被許多社會和魔法實踐者視作禁忌", "p": [11] },
	{ "s": "被迫於懲奸除惡或贏取榮耀", "p": [11] }
];