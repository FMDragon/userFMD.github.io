DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u92b3"] = [
	{ "s": "銳眼緊盯着入侵者", "p": [11] }
];