DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0054"] = [
	{ "s": "T", "p": [8, 2] },
	{ "s": "TEXT", "p": [8, 2] },
	{ "s": "THIS", "p": [8, 2] },
	{ "s": "TITLE", "p": [1] },
	{ "s": "TO", "p": [8, 2] },
	{ "s": "TODO", "p": [8, 2] },
	{ "s": "TOPIC", "p": [8, 2] }
];