DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0054"] = [
	{ "s": "T", "p": [13, 10, 8, 2] },
	{ "s": "TEXT", "p": [13, 10, 8, 2] },
	{ "s": "THIS", "p": [13, 10, 8, 2] },
	{ "s": "TITLE", "p": [1] },
	{ "s": "TO", "p": [13, 10, 8, 2] },
	{ "s": "TODO", "p": [13, 10, 8, 2] },
	{ "s": "TOPIC", "p": [13, 10, 8, 2] }
];