DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7d50"] = [
	{ "s": "結果發現整體使用度不到一半", "p": [5] },
	{ "s": "結社中最具智能的成員會作爲團體中掌握着上古誓約的祭司長", "p": [11] }
];