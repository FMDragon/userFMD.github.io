DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u986f"] = [
	{ "s": "顯示前輩們的辛勤勞作", "p": [5] }
];