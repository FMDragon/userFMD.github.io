DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f75"] = [
	{ "s": "併爲這些傳說賦予生命", "p": [11] }
];