DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u67af"] = [
	{ "s": "枯朽", "p": [11] },
	{ "s": "枯朽：驅使生命和自然魔法的施法者常常會被吸引到一處特定的神殿或自然場所，並讓他們的肉體與精魂與這些充滿魔法力量的場所形成紐帶。德魯伊們從這些地點汲取生命力，並窮盡一生來守護它——但並非所有的德魯伊都成功守護了自己的聖所", "p": [11] }
];