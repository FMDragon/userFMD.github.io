DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6b64"] = [
	{ "s": "此宗派的武術基本便是模仿龍之姿態", "p": [11] }
];