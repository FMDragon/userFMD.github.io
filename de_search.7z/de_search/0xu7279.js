DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7279"] = [
	{ "s": "特別是那些在世界上仍有重大偉業等待他們完成的人們", "p": [11] }
];