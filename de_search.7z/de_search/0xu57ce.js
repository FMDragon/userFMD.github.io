DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u57ce"] = [
	{ "s": "城市守衛", "p": [9] },
	{ "s": "城市賞金獵人", "p": [9] }
];