DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7372"] = [
	{ "s": "獲得一件常見的武器或護甲", "p": [7] },
	{ "s": "獲得３００ＧＰ", "p": [7] }
];