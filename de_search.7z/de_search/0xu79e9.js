DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u79e9"] = [
	{ "s": "秩序", "p": [11] },
	{ "s": "秩序的力量也許對旁人來說有些奇怪", "p": [11] },
	{ "s": "秩序領域代表着紀律", "p": [11] },
	{ "s": "秩序：秩序領域代表着紀律，對一個社會或制度的忠誠、以及對其統治法律的嚴格服從", "p": [11] }
];