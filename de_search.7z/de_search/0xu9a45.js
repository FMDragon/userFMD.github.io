DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9a45"] = [
	{ "s": "驅使生命和自然魔法的施法者常常會被吸引到一處特定的神殿或自然場所", "p": [11] },
	{ "s": "驅逐", "p": [11] }
];