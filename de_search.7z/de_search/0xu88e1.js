DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u88e1"] = [
	{ "s": "裡面排列著整齊的木架", "p": [5] }
];