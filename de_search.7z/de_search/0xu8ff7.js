DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ff7"] = [
	{ "s": "迷惑", "p": [11] },
	{ "s": "迷惑學院", "p": [11] },
	{ "s": "迷惑意識", "p": [11] },
	{ "s": "迷惑：迷惑學院，是那些在妖精荒野的活潑國度中精通他們技藝、或受到該地居民教導的吟遊詩人們的家園。在薩特羊人、雅靈、以及其他精類生物的教導下，這些詩人們學會運用他們的魔法以取悅和迷惑他人", "p": [11] }
];