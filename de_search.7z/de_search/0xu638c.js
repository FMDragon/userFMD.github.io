DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u638c"] = [
	{ "s": "掌管奧祕領域的神祗詳盡知曉魔法的祕密和潛能", "p": [11] },
	{ "s": "掌管生命領域的神祇傳播活力與健康", "p": [11] }
];