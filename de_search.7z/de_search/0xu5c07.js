DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5c07"] = [
	{ "s": "將其磨練到完美", "p": [11] },
	{ "s": "將這類生物視爲自己的責任", "p": [11] }
];