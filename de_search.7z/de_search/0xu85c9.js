DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u85c9"] = [
	{ "s": "藉由醫治疾病與創傷", "p": [11] }
];