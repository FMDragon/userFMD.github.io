DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u537b"] = [
	{ "s": "卻有着豐富生命的能力", "p": [11] }
];