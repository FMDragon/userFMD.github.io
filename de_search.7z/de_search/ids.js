DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex.ids = {
	"1": ["Ti... Paid license required!", "index.htm", []],
	"2": ["1. 背... Paid license required!", "world view.htm", []],
	"3": ["1.1. 這... Paid license required!", "what happened.htm", [1]],
	"4": ["1.2. 玩家... Paid license required!", "how to appear.htm", [1]],
	"5": ["1.3. ... Paid license required!", "what is quiyyuar.htm", [1]],
	"6": ["1.3.1.... Paid license required!", "quiyyuar's library.htm", [1,6]],
	"7": ["2. ... Paid license required!", "create.htm", []],
	"8": ["2.1. 如... Paid license required!", "how to create.htm", [2]],
	"9": ["2.2... Paid license required!", "background.htm", [2]],
	"10": ["2.3... Paid license required!", "race.htm", [2]],
	"11": ["2.4... Paid license required!", "profession.htm", [2]],
	"12": ["2.4.1.... Paid license required!", "profession pk.htm", [2,10]],
	"13": ["A topic wit... Paid license required!", "a_topic_without_number.htm", []]
};