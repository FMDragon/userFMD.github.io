DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex.ids = {
	"1": ["Ti... Paid license required!", "index.htm", []],
	"2": ["1. 背... Paid license required!", "______2.htm", []],
	"3": ["1.1. 這... Paid license required!", "________.htm", [1]],
	"4": ["1.2. 玩家... Paid license required!", "_________.htm", [1]],
	"5": ["1.3. ... Paid license required!", "_______1.htm", [1]],
	"6": ["1.3.1.... Paid license required!", "_______2.htm", [1,6]],
	"7": ["2. ... Paid license required!", "____.htm", []],
	"8": ["2.1. 如... Paid license required!", "_______.htm", [2]],
	"9": ["2.2... Paid license required!", "___2.htm", [2]],
	"10": ["2.3... Paid license required!", "___3.htm", [2]],
	"11": ["2.4... Paid license required!", "___4.htm", [2]],
	"12": ["2.4.1.... Paid license required!", "_______3.htm", [2,10]],
	"13": ["A topic wit... Paid license required!", "a_topic_without_number.htm", []]
};