DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u91cb"] = [
	{ "s": "釋放俘虜", "p": [11] },
	{ "s": "釋放強力的攻擊", "p": [11] }
];