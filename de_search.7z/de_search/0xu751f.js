DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u751f"] = [
	{ "s": "生命", "p": [11] },
	{ "s": "生命領域專注於精力充沛的正能量", "p": [11] },
	{ "s": "生命：生命領域專注於精力充沛的正能量—構成宇宙的其中一種基本力量—維持所有生命的延續。掌管生命領域的神祇傳播活力與健康，藉由醫治疾病與創傷、照料需要的人們、並驅趕死亡和亡靈的勢力", "p": [11] }
];