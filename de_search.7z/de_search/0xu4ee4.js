DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4ee4"] = [
	{ "s": "令人敬畏的龍族力量", "p": [11] }
];