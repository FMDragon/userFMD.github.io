DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53ea"] = [
	{ "s": "只剩下一片黑暗", "p": [11] },
	{ "s": "只有少數生者試圖生存", "p": [3] },
	{ "s": "只有生命的沙漏匆匆流逝的人纔會在意", "p": [11] },
	{ "s": "只有還能喚醒的英烈之魂", "p": [7] },
	{ "s": "只留下無數迷霧般的傳說與等待探索的秘密", "p": [3] }
];