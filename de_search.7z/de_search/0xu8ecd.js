DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ecd"] = [
	{ "s": "軍力與文化享譽大陸", "p": [3] },
	{ "s": "軍士的士氣低落", "p": [3] },
	{ "s": "軍隊需要保護", "p": [11] }
];