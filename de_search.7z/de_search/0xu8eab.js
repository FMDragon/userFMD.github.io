DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8eab"] = [
	{ "s": "身爲夢境結社成員的德魯伊們來自那些與妖精荒野與那夢境般國度有着強烈聯繫的地區", "p": [11] },
	{ "s": "身爲守護者和醫生的結合", "p": [11] },
	{ "s": "身爲影之造物", "p": [11] },
	{ "s": "身着閃亮的盔甲", "p": [11] },
	{ "s": "身體力量", "p": [11] }
];