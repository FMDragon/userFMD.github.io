DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6703"] = [
	{ "s": "會有微弱的回音", "p": [6] },
	{ "s": "會根據玩家的行為改變", "p": [6] }
];