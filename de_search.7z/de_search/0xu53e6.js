DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53e6"] = [
	{ "s": "另一些惑控師則是暴君", "p": [11] },
	{ "s": "另一些變化看上去就比較戲劇性了", "p": [11] },
	{ "s": "另一邊取走別人的性命", "p": [11] }
];