DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u727d"] = [
	{ "s": "牽魂人", "p": [4] },
	{ "s": "牽魂人以此祭壇將亡魂引導至烈士的軀殼", "p": [5] },
	{ "s": "牽魂人每次召喚新靈魂時", "p": [5] }
];