DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0041"] = [
	{ "s": "A", "p": [13] },
	{ "s": "ADD", "p": [13, 10, 8, 2] },
	{ "s": "AND", "p": [13, 10, 8, 2] }
];