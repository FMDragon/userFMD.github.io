DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0041"] = [
	{ "s": "ADD", "p": [8, 2] },
	{ "s": "AND", "p": [8, 2] },
	{ "s": "ASCHE", "p": [1] },
	{ "s": "AUS", "p": [1] }
];