DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8a46"] = [
	{ "s": "詆譭這個學派的人們宣稱它的傳統充滿着否認和拒絕", "p": [11] }
];