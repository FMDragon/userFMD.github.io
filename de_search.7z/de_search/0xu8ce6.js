DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ce6"] = [
	{ "s": "賦予他們新的生命與使命", "p": [4] }
];