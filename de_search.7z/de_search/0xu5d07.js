DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5d07"] = [
	{ "s": "崇敬着整個大自然本身的德魯伊也可能會侍奉於其中一個神祇", "p": [11] }
];