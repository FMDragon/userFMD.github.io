DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u628a"] = [
	{ "s": "把自己表現成一名無貌的生死判官", "p": [11] }
];