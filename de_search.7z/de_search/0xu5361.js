DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5361"] = [
	{ "s": "卡薩CATHA和茹蒂斯RUIDUS", "p": [11] }
];