DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u81f3"] = [
	{ "s": "至於其他宗派則可能更像是盜賊公會", "p": [11] }
];