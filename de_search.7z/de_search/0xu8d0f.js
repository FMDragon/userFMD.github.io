DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8d0f"] = [
	{ "s": "贏取懷疑者的堅信和貶低者的較好", "p": [11] }
];