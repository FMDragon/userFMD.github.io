DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5b89"] = [
	{ "s": "安全地從對手身邊飛奔而去", "p": [11] },
	{ "s": "安撫垂死之人的痛苦", "p": [11] }
];