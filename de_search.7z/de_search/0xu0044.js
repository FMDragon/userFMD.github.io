DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0044"] = [
	{ "s": "DESCRIPTION", "p": [13, 10, 8, 2] },
	{ "s": "DND5E系統", "p": [1] },
	{ "s": "DON", "p": [13, 10, 8, 2] },
	{ "s": "DON'T", "p": [13, 10, 8, 2] },
	{ "s": "DUNAMIS", "p": [11] }
];