DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0044"] = [
	{ "s": "DER", "p": [1] },
	{ "s": "DESCRIPTION", "p": [8, 2] },
	{ "s": "DND5E系統", "p": [1] },
	{ "s": "DON", "p": [8, 2] },
	{ "s": "DON'T", "p": [8, 2] },
	{ "s": "DUNAMIS", "p": [11] }
];