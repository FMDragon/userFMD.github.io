DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f8b"] = [
	{ "s": "例如世界盡頭的極寒地帶", "p": [11] }
];