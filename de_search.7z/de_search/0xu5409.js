DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5409"] = [
	{ "s": "吉斯人", "p": [10] },
	{ "s": "吉斯洋基人", "p": [10] },
	{ "s": "吉斯澤萊人", "p": [10] }
];