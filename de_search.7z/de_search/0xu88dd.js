DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u88dd"] = [
	{ "s": "裝甲就像是第二層皮膚", "p": [11] },
	{ "s": "裝甲師", "p": [11] },
	{ "s": "裝甲師：對於裝甲師專業的奇械師來說，裝甲就像是第二層皮膚。這一裝甲能夠增強奇械師的魔法，釋放強力的攻擊，產生絕佳的防護。這些奇械師與他們的裝甲之間有着強力的紐帶，在他們經過實驗並改進裝甲的魔法性能後，甚至能夠合二爲一", "p": [11] }
];