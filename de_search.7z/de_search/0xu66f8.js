DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u66f8"] = [
	{ "s": "書之魔法", "p": [11] },
	{ "s": "書士", "p": [11] },
	{ "s": "書士：許多人將法師魔法稱爲\"書之魔法\"，想想法師爲研讀卷宗與書寫魔法理論花費了多少時間，這稱呼也是名副其實。旅行中的法師包裏，總是撐滿書本卷宗；若能一探遠古知識，法師願意赴湯蹈火", "p": [11] },
	{ "s": "書架高聳入天花板", "p": [6] }
];