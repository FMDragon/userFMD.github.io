DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5c24"] = [
	{ "s": "尤其是那些善良龍族", "p": [11] },
	{ "s": "尤其是那些野獸和妖精的精魂", "p": [11] },
	{ "s": "尤其是那維繫着社會的法律", "p": [11] }
];