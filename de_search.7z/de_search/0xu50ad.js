DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u50ad"] = [
	{ "s": "傭兵老將", "p": [9] },
	{ "s": "傭兵老將：你深知傭兵生涯中只有經歷過才能理解的一切。你能夠藉由其他人的佩章辨識出其他的傭兵團，且你知道一些關於這類傭兵團的事情，包包括誰最近僱傭了他們等等", "p": [9] }
];