DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5e38"] = [
	{ "s": "常常用面具遮住自己的臉", "p": [11] },
	{ "s": "常見的像是盤龍", "p": [11] },
	{ "s": "常見背景", "p": [9] }
];