DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7149"] = [
	{ "s": "煉獄傳承基因", "p": [10] },
	{ "s": "煉金師", "p": [11] },
	{ "s": "煉金師：鍊金師是將奇異的原料混合在一起以產生種種新物質的專家，鍊金師的創造物能用來延續生命，也能用來奪走生命。鍊金術是最古老的奇械師技藝，它的多功能性在戰爭與和平時都長期受到重視", "p": [11] }
];