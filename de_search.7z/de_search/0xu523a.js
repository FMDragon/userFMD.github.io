DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u523a"] = [
	{ "s": "刺客", "p": [11] },
	{ "s": "刺客：你專注你的訓練於殘忍冷酷的死亡藝術。那些遵從這個範型的人們有各式各樣：僱傭殺手、間諜、賞金獵人、和甚至那些受訓於爲他們神祇殲滅敵人的特殊祭司。隱匿、用毒、和易容都能幫助你在排除敵人時發揮致命的奇效", "p": [11] }
];