DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u89d2"] = [
	{ "s": "角冠騎士", "p": [11] },
	{ "s": "角色啟用", "p": [7] }
];