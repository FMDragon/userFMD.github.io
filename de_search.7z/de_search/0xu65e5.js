DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u65e5"] = [
	{ "s": "日魂宗", "p": [11] },
	{ "s": "日魂宗的武僧學會如何將自己的生命能量引導轉換成熾熱的光芒", "p": [11] },
	{ "s": "日魂宗：日魂宗的武僧學會如何將自己的生命能量引導轉換成熾熱的光芒。他們被教導使用一種特殊的冥想方式，讓其能解放將存在於每一個活物靈魂中的不滅光芒釋放而出的能力", "p": [11] }
];