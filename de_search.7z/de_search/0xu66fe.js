DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u66fe"] = [
	{ "s": "曾經的亡者", "p": [4] },
	{ "s": "曾經的偉大文明已經崩塌", "p": [3] },
	{ "s": "曾經繁榮的王國如今只剩下斷垣殘壁", "p": [3] },
	{ "s": "曾被譽為", "p": [3] }
];