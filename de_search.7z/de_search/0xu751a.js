DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u751a"] = [
	{ "s": "甚至傳送到另一個存在位面", "p": [11] },
	{ "s": "甚至提供強大的咒語與武器設計圖", "p": [6] },
	{ "s": "甚至能夠合二爲一", "p": [11] },
	{ "s": "甚至能欺騙最有智能之人的魔法", "p": [11] },
	{ "s": "甚至達到了", "p": [11] },
	{ "s": "甚至騰展龍翼", "p": [11] }
];