DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8490"] = [
	{ "s": "蒐集種種不同的軼聞", "p": [11] }
];