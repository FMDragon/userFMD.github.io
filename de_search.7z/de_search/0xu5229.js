DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5229"] = [
	{ "s": "利用可預期的祕跡", "p": [11] },
	{ "s": "利用魔法強迫不情願的人們爲他工作", "p": [11] }
];