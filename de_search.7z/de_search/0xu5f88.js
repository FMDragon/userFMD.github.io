DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5f88"] = [
	{ "s": "很多吉斯洋基人受訓成爲這樣的戰士", "p": [11] }
];