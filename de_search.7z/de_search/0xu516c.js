DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u516c"] = [
	{ "s": "公會工匠", "p": [9] }
];