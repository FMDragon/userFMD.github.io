DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u516c"] = [
	{ "s": "公會工匠", "p": [9] },
	{ "s": "公會工匠：作爲一名正式且受人尊敬的公會成員，你可以享有會員身分所提供給你的某些好處。若有必要，你的公會成員同事會提供你所需的住宿與食物，且在必要的時候支付你的喪葬費用", "p": [9] }
];