DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u65bd"] = [
	{ "s": "施予他人最需要的幫助", "p": [11] }
];