DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9664"] = [
	{ "s": "除了提升你的靈巧和隱匿技術之外", "p": [11] },
	{ "s": "除非你讓他們覺得你是個危害", "p": [9] }
];