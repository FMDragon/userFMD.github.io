DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8f49"] = [
	{ "s": "轉而將墮影冥界中的黑暗魔法編入他們的法術施展中", "p": [11] }
];