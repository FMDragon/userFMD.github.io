DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u767d"] = [
	{ "s": "白天時陽光能夠灑下柔和的光線", "p": [6] },
	{ "s": "白騎士", "p": [11] }
];