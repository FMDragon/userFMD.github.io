DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9020"] = [
	{ "s": "造成兼具戲劇性和毀滅性的效果", "p": [11] }
];