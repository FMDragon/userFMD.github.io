DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ca1"] = [
	{ "s": "財慾之魂", "p": [7] },
	{ "s": "財慾之魂：獲得３００ＧＰ", "p": [7] }
];