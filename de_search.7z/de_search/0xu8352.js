DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8352"] = [
	{ "s": "荒野中隱藏著未知的危險與被遺忘的秘密", "p": [3] },
	{ "s": "荒野之力流淌於德魯伊的血液中", "p": [11] }
];