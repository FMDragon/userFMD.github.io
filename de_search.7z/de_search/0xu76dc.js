DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u76dc"] = [
	{ "s": "盜賊工會對鬼魅們高度重視", "p": [11] }
];