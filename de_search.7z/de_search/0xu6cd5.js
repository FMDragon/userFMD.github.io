DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6cd5"] = [
	{ "s": "法師", "p": [12, 11] },
	{ "s": "法師願意赴湯蹈火", "p": [11] },
	{ "s": "法師：開局贈送「魔法學徒(任一)」專長", "p": [12] },
	{ "s": "法術補足並拓展了他們的武技", "p": [11] }
];