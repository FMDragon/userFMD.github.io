DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0048"] = [
	{ "s": "HERE", "p": [8, 2] },
	{ "s": "HERR", "p": [1] }
];