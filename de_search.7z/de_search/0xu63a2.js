DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u63a2"] = [
	{ "s": "探索者", "p": [11] },
	{ "s": "探險家", "p": [11] }
];