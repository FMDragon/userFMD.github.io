DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6291"] = [
	{ "s": "抑或是使你成爲恐懼之源", "p": [11] }
];