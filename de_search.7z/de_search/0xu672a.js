DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u672a"] = [
	{ "s": "未經允許", "p": [6] },
	{ "s": "未經允許，請勿進入書架深處。你可能會迷路，或失去更多", "p": [6] }
];