DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u96c4"] = [
	{ "s": "雄辯", "p": [11] },
	{ "s": "雄辯學院的學徒們熟練的掌握了演說的藝術", "p": [11] },
	{ "s": "雄辯：雄辯學院的學徒們熟練的掌握了演說的藝術。這些吟遊詩人舞動着牢不可破的邏輯與誇張的文字遊戲二重奏，用邏輯的論斷與叩擊心絃的感染力，順着觀衆的情感不斷出擊，贏取懷疑者的堅信和貶低者的較好", "p": [11] }
];