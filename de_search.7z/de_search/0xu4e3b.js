DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4e3b"] = [
	{ "s": "主要以乾糧和不易腐壞的物資為主", "p": [5] }
];