DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6211"] = [
	{ "s": "我們情感豐富而激烈的老夥計們", "p": [11] }
];