DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6210"] = [
	{ "s": "成為戰友的支撐", "p": [11] },
	{ "s": "成為無人知曉的英魂", "p": [4] },
	{ "s": "成為鈷魂宗的一員", "p": [11] },
	{ "s": "成爲從遠方轟炸敵軍的砲臺", "p": [11] },
	{ "s": "成爲破誓者的聖武士打破了自己的神聖誓言", "p": [11] },
	{ "s": "成羣的獸人", "p": [11] }
];