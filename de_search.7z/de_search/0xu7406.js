DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7406"] = [
	{ "s": "理解並掌控着將物體的物質聚合或分離的力量", "p": [11] },
	{ "s": "理論", "p": [11] }
];