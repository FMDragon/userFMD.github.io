DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5979"] = [
	{ "s": "她將這些沉眠的烈士喚醒", "p": [4] }
];