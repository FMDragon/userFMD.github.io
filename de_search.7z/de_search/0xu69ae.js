DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u69ae"] = [
	{ "s": "榮耀", "p": [11] },
	{ "s": "榮耀：對榮耀宣誓的聖武士堅信他們將與同伴一起達成英勇的偉業，並命中註定以此取得榮耀。他們將刻苦訓練，砥礪前行，從而確保當命運決定的時刻到來之際，他們都已有所準備", "p": [11] }
];