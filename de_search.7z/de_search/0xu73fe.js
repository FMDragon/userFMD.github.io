DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u73fe"] = [
	{ "s": "現在", "p": [11, 7] },
	{ "s": "現實之外的宇宙", "p": [11] }
];