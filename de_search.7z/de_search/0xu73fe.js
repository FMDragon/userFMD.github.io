DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u73fe"] = [
	{ "s": "現在", "p": [11, 7] },
	{ "s": "現在你必須更多地了解這個隱藏的真相", "p": [9] },
	{ "s": "現實之外的宇宙", "p": [11] }
];