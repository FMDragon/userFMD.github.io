DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5be6"] = [
	{ "s": "實則隱藏着一段被精心運行的舞蹈", "p": [11] }
];