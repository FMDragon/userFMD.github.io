DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u796d"] = [
	{ "s": "祭壇是一座由黑色岩石鑄成的平臺", "p": [5] },
	{ "s": "祭壇是一座由黑色岩石鑄成的平臺，其上燃燒著不熄的藍色火焰。火焰閃爍著幽光，彷彿在訴說靈魂的故事。牽魂人以此祭壇將亡魂引導至烈士的軀殼，使之重生", "p": [5] }
];