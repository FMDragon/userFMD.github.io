DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u56db"] = [
	{ "s": "四象宗", "p": [11] },
	{ "s": "四象宗：你遵循着一個教導你駕馭元素之力的宗派傳統。當你凝神運氣時，你可以使你自己調和於創造和操縱四元素之力，如臂使指般驅使它們。這個宗派的部分成員投身於單一元素，而其它人則將四元素織爲一體", "p": [11] }
];