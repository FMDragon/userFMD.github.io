DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u540c"] = [
	{ "s": "同時又加以擴展", "p": [11] },
	{ "s": "同時大多數政府也樂意僱傭他們作爲間諜", "p": [11] },
	{ "s": "同時環繞在它們的武器上", "p": [11] },
	{ "s": "同等兼顧着速度", "p": [11] }
];