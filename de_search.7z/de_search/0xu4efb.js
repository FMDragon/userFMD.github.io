DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4efb"] = [
	{ "s": "任一", "p": [12] },
	{ "s": "任何疲憊的人都能找到休憩的場所", "p": [11] },
	{ "s": "任何術士都可能因爲契約或其他因素", "p": [11] }
];