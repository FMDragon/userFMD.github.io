DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8d70"] = [
	{ "s": "走上了野獸道途的野蠻人從他們靈魂中熊熊燃燒的野獸汲取怒火與力量", "p": [11] }
];