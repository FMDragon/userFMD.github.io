DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8056"] = [
	{ "s": "聖戰士", "p": [11] },
	{ "s": "聖武士", "p": [12, 11] },
	{ "s": "聖武士們就會出現", "p": [11] },
	{ "s": "聖武士心中燃燒的光耀已經熄滅", "p": [11] },
	{ "s": "聖武士：每次聖療需要使用5點以上", "p": [12] }
];