DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u92fc"] = [
	{ "s": "鋼鐵守衛來輔助自己", "p": [11] }
];