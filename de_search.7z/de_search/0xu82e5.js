DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u82e5"] = [
	{ "s": "若他們能解開多元宇宙中的祕密", "p": [11] },
	{ "s": "若你所屬的教團是宗教性的", "p": [9] },
	{ "s": "若書架間的燈忽然熄滅", "p": [6] },
	{ "s": "若書架間的燈忽然熄滅，請立刻返回起點", "p": [6] },
	{ "s": "若有必要", "p": [9] },
	{ "s": "若能一探遠古知識", "p": [11] }
];