DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u66ae"] = [
	{ "s": "暮光", "p": [11] },
	{ "s": "暮光：在光明隱沒，黑暗顯現的迷離境界中，人們結束了白天的工作並開始休息。這是平靜之時，這是歡愉之時，這是暮光之時。儘管令人恐懼之物潛伏於黑暗之中，但莫要驚慌，因暮光之神們將抵擋這些夜之恐怖", "p": [11] },
	{ "s": "暮行者", "p": [1] }
];