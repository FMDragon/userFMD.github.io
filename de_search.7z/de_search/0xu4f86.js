DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f86"] = [
	{ "s": "來再一次改變世界", "p": [11] },
	{ "s": "來自四面八方的人們都到鈷魂書院尋找知識", "p": [11] }
];