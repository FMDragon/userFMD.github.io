DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5373"] = [
	{ "s": "即使他們使用武器來表演娛樂", "p": [11] },
	{ "s": "即使你可能致力對抗於它們的邪惡目的", "p": [11] },
	{ "s": "即使是最頑劣的金屬", "p": [11] },
	{ "s": "即使曾爲凡人", "p": [11] },
	{ "s": "即使舊日支配者可能並未意識到你的存在", "p": [11] },
	{ "s": "即爲星我", "p": [11] }
];