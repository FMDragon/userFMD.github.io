DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u63ed"] = [
	{ "s": "揭露隱藏在陰影中的秘密", "p": [9] }
];