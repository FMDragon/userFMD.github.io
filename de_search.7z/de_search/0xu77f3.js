DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u77f3"] = [
	{ "s": "石室的牆壁上掛滿了來自外界的獵物骨架與皮毛", "p": [5] },
	{ "s": "石牆在昏暗中散發著微弱的光", "p": [5] }
];