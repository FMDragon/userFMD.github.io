DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8cb4"] = [
	{ "s": "貴族", "p": [9] },
	{ "s": "貴族內鬥", "p": [3] }
];