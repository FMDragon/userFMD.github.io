DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8cb4"] = [
	{ "s": "貴族", "p": [9] },
	{ "s": "貴族內鬥", "p": [3] },
	{ "s": "貴族：由於你的貴族出身，人們會傾向記住你最好的一面。你在上流社會受到歡迎，且人們會認爲你有權出現在任何地方。平民盡他所可能遷就你並避免惹惱你，而其他出身高貴的人將你視爲他們社交圈的一份子", "p": [9] }
];