DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9996"] = [
	{ "s": "首次復生的玩家可以創建一張等級３的角色卡並從下列2種復生之魂中選擇一個", "p": [7] }
];