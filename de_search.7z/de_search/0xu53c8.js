DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53c8"] = [
	{ "s": "又或者", "p": [11] },
	{ "s": "又或者你曾暴露於墮影冥界的可怕能量之下並被其轉化", "p": [11] },
	{ "s": "又或者你的魔法僅僅是你誕生時僥倖獲得", "p": [11] },
	{ "s": "又或許", "p": [11] }
];