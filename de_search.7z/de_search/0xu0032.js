DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0032"] = [
	{ "s": "2", "p": [9, 12, 11, 10, 8, 7, 4, 6] },
	{ "s": "2.1", "p": [8] },
	{ "s": "2.2", "p": [9] },
	{ "s": "2.3", "p": [10] },
	{ "s": "2.4", "p": [11] },
	{ "s": "2.4.1", "p": [12] },
	{ "s": "2025", "p": [1] }
];