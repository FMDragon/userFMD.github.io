DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5947"] = [
	{ "s": "奇怪的心靈力量", "p": [11] },
	{ "s": "奇械師", "p": [11] }
];