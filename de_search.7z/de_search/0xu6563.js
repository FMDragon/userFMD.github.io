DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6563"] = [
	{ "s": "散打宗", "p": [11] },
	{ "s": "散打宗的武僧都是武術格鬥的終極大師", "p": [11] },
	{ "s": "散打宗：散打宗的武僧都是武術格鬥的終極大師，無論是持武還是空手。他們學習推撞與絆摔對手的技巧、操作氣以治療他們身體所受的傷害、並施展能夠保護他們不受傷害的深度冥想", "p": [11] }
];