DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7834"] = [
	{ "s": "破誓", "p": [11] },
	{ "s": "破誓：成爲破誓者的聖武士打破了自己的神聖誓言，而去追求黑暗的野心或爲邪惡力量服務。聖武士心中燃燒的光耀已經熄滅，只剩下一片黑暗", "p": [11] }
];