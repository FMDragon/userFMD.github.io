DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5167"] = [
	{ "s": "內憂與外患如同交織的荊棘", "p": [3] }
];