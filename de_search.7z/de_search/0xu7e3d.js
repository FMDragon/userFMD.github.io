DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7e3d"] = [
	{ "s": "總是撐滿書本卷宗", "p": [11] }
];