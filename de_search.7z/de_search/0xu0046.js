DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0046"] = [
	{ "s": "FOR", "p": [13, 10, 8, 2] },
	{ "s": "FORGET", "p": [13, 10, 8, 2] }
];