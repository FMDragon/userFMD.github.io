DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9806"] = [
	{ "s": "順着觀衆的情感不斷出擊", "p": [11] }
];