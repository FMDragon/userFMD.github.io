DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7ce7"] = [
	{ "s": "糧倉", "p": [5] },
	{ "s": "糧倉位於教堂的一翼", "p": [5] },
	{ "s": "糧倉位於教堂的一翼，是一個大型的石室，裡面排列著整齊的木架，上面堆滿布包的糧食與器具。石室的牆壁上掛滿了來自外界的獵物骨架與皮毛，顯示前輩們的辛勤勞作", "p": [5] }
];