DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5916"] = [
	{ "s": "外牆佈滿蔓藤", "p": [5] },
	{ "s": "外觀", "p": [5] },
	{ "s": "外觀描述", "p": [5] }
];