DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5916"] = [
	{ "s": "外牆佈滿蔓藤", "p": [5] },
	{ "s": "外觀", "p": [5] },
	{ "s": "外觀描述", "p": [5] },
	{ "s": "外觀選擇", "p": [10] },
	{ "s": "外觀選擇（拾荒種／龍國血統）※此處選擇不會改變屬性", "p": [10] }
];