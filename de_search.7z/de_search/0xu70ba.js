DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u70ba"] = [
	{ "s": "為甲胄提供額外的保護", "p": [11] }
];