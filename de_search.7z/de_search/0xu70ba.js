DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u70ba"] = [
	{ "s": "為戰而存", "p": [1] },
	{ "s": "為甲胄提供額外的保護", "p": [11] },
	{ "s": "為高薪客戶解開謎團", "p": [9] }
];