DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7f6a"] = [
	{ "s": "罪犯", "p": [9] },
	{ "s": "罪犯：你有着一個可靠且可以信賴的聯繫人，能作爲你與其他罪犯聯繫的橋樑。你知道如何接收或傳遞消息給你的聯繫人，即使你們之間相隔甚遠也一樣；具體來說，你可能認識當地的信使、貪腐的商隊長、以及能夠爲你傳遞消息的骯髒水手", "p": [9] }
];