DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u91cd"] = [
	{ "s": "重力", "p": [11] },
	{ "s": "重力奧術傳承的學生們通過學習來更進一步掌控扭曲並操縱重力的狂暴能量來增益自己", "p": [11] },
	{ "s": "重力：理解並掌控着將物體的物質聚合或分離的力量，重力奧術傳承的學生們通過學習來更進一步掌控扭曲並操縱重力的狂暴能量來增益自己，或是爲他們的敵人帶來恐怖的傷害", "p": [11] }
];