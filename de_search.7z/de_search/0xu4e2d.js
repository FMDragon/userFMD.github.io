DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4e2d"] = [
	{ "s": "中央有一座拱形天窗", "p": [6] },
	{ "s": "中央矗立著藍焰祭壇", "p": [5] }
];