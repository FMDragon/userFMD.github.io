DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u633a"] = [
	{ "s": "挺身對抗那威脅於摧毀文明世界的野蠻混亂浪潮", "p": [11] }
];