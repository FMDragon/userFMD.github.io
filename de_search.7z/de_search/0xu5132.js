DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5132"] = [
	{ "s": "儲存著由前輩們從外界帶回的食物與資源", "p": [5] },
	{ "s": "儲存著由前輩們從外界帶回的食物與資源，主要以乾糧和不易腐壞的物資為主", "p": [5] }
];