DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u64c1"] = [
	{ "s": "擁抱這個範型的遊蕩者許多都以荒野爲家", "p": [11] },
	{ "s": "擁有着這種祝福靈魂", "p": [11] }
];