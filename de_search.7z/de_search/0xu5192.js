DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5192"] = [
	{ "s": "冒險者", "p": [11] },
	{ "s": "冒險者們相信", "p": [3] }
];