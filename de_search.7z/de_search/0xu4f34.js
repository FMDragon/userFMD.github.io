DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4f34"] = [
	{ "s": "伴隨着代價", "p": [11] },
	{ "s": "伴隨着對於現實本質的特殊理解", "p": [11] }
];