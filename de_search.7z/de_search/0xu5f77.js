DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5f77"] = [
	{ "s": "彷彿在引誘知識的探索者", "p": [5] },
	{ "s": "彷彿在為過去的榮耀哀悼", "p": [3] },
	{ "s": "彷彿在訴說靈魂的故事", "p": [5] },
	{ "s": "彷彿為亡靈們的歸來而設計", "p": [5] },
	{ "s": "彷彿無窮無盡", "p": [6] },
	{ "s": "彷彿腳下的石頭也在低聲訴說什麼", "p": [6] },
	{ "s": "彷彿遺忘與時間無法觸及的存在", "p": [5] }
];