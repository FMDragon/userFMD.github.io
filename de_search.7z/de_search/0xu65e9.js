DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u65e9"] = [
	{ "s": "早已解開永生生命的祕密", "p": [11] }
];