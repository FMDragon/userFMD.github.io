DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u80fd"] = [
	{ "s": "能展現他們的真我", "p": [11] },
	{ "s": "能量", "p": [11] },
	{ "s": "能量，這些法師可以像熟練的樂師演奏樂器那樣扭曲時間的流動，在眨眼間賦予他們自己以及他們的盟友戰鬥優勢", "p": [11] }
];