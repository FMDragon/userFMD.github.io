DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u591c"] = [
	{ "s": "夜晚的圖書館可成為一次高風險高回報的冒險", "p": [6] },
	{ "s": "夜晚的圖書館可成為一次高風險高回報的冒險。玩家可以挑戰自己的勇氣，嘗試從禁書中取得關鍵信息，但後果往往無法預料", "p": [6] }
];