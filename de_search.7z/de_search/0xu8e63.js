DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8e63"] = [
	{ "s": "蹣跚搖擺着他的雙腳", "p": [11] }
];