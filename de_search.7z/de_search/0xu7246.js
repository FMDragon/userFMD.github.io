DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7246"] = [
	{ "s": "牆上掛著油燈", "p": [5] },
	{ "s": "牆上還掛著一些未完成的裝備與武器藍圖", "p": [5] }
];