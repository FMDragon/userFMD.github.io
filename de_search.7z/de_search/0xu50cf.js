DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u50cf"] = [
	{ "s": "像是武器鍛造和書法等等", "p": [11] }
];