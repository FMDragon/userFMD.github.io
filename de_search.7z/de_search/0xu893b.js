DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u893b"] = [
	{ "s": "褻瀆亡者死後的寧靜是不可饒恕的重罪", "p": [11] }
];