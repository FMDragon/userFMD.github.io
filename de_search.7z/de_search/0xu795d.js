DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u795d"] = [
	{ "s": "祝福忠實信徒們的收穫", "p": [11] }
];