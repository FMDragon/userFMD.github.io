DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u900f"] = [
	{ "s": "透過研究", "p": [11] },
	{ "s": "透過細緻的訓練", "p": [11] }
];