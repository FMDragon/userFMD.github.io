DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6b77"] = [
	{ "s": "歷史", "p": [11] },
	{ "s": "歷史和資訊的檔案館之一", "p": [11] },
	{ "s": "歷史背景", "p": [3] },
	{ "s": "歷戰之魂", "p": [7] },
	{ "s": "歷戰之魂：獲得一件常見的武器或護甲（３００ＧＰ以下）、５０ＧＰ", "p": [7] }
];