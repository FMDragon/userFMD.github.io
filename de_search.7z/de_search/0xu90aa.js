DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u90aa"] = [
	{ "s": "邪惡精類", "p": [11] },
	{ "s": "邪魔", "p": [11] },
	{ "s": "邪魔：即使你可能致力對抗於它們的邪惡目的，你仍與一個來自下層位面的邪魔締結了契約。這類存在渴望着世間萬物的腐化或破壞，最終也包括了你", "p": [11] }
];