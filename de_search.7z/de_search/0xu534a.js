DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u534a"] = [
	{ "s": "半獸人", "p": [10] },
	{ "s": "半精靈", "p": [10] },
	{ "s": "半身人", "p": [10] }
];