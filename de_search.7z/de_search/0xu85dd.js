DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u85dd"] = [
	{ "s": "藝人", "p": [9] },
	{ "s": "藝人：你總是能找到表演場地，這些地方通常會是酒館或客棧，但也可能會是在馬戲團、劇院、甚至是貴族廳堂", "p": [9] }
];