DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0031"] = [
	{ "s": "1", "p": [6, 3, 12, 8, 5, 4, 2] },
	{ "s": "1.1", "p": [3] },
	{ "s": "1.2", "p": [4] },
	{ "s": "1.3", "p": [5] },
	{ "s": "1.3.1", "p": [6] },
	{ "s": "10", "p": [6] }
];