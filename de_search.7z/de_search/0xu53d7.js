DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53d7"] = [
	{ "s": "受你的心靈所傷害呢", "p": [11] },
	{ "s": "受到所住社區的喜愛", "p": [11] },
	{ "s": "受過用以戰勝這類怪物的超自然技術訓練", "p": [11] }
];