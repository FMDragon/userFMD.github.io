DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u63d0"] = [
	{ "s": "提供他們的服務給貴族", "p": [11] },
	{ "s": "提供新的知識", "p": [6] },
	{ "s": "提供昏暗的光源", "p": [5] },
	{ "s": "提夫林", "p": [11] }
];