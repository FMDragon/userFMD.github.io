DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5e0c"] = [
	{ "s": "希望能使他們的敵人棄暗投明", "p": [11] },
	{ "s": "希求顯耀他們先祖的那不屬於這個世界的魔力", "p": [11] }
];