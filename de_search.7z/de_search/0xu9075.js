DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9075"] = [
	{ "s": "遵循巨像道途的野蠻人堅定不移", "p": [11] },
	{ "s": "遵循這條道路的聖武士們也被稱作救贖者", "p": [11] }
];