DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5f8c"] = [
	{ "s": "後來並非精靈的修習者也開始採用", "p": [11] }
];