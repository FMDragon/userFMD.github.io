DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9078"] = [
	{ "s": "選擇踏上巨人道途的野蠻人從巨人和他們的元素同族中汲取力量", "p": [11] }
];