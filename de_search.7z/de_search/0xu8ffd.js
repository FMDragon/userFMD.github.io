DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ffd"] = [
	{ "s": "追隨時間使傳承的法師們專注於操縱時間", "p": [11] },
	{ "s": "追隨着風暴先驅道途的野蠻人們學會將這狂暴轉變成環繞在他們周遭的原初魔法", "p": [11] },
	{ "s": "追隨這條道途的野蠻人會以歌頌他們先祖事蹟的精巧紋身覆蓋他們的身體", "p": [11] }
];