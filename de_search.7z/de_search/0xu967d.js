DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u967d"] = [
	{ "s": "陽光透過彩繪玻璃灑落", "p": [5] }
];