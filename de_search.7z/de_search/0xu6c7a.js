DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6c7a"] = [
	{ "s": "決鬥家和海盜都屬於這個範型", "p": [11] }
];