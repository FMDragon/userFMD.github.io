DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u60e1"] = [
	{ "s": "惡作劇", "p": [11] },
	{ "s": "惡棍", "p": [11] }
];