DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u71be"] = [
	{ "s": "熾天神侍", "p": [11] },
	{ "s": "熾熱火焰", "p": [11] }
];