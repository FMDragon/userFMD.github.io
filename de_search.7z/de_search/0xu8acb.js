DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8acb"] = [
	{ "s": "請勿進入書架深處", "p": [6] },
	{ "s": "請勿閱讀", "p": [6] },
	{ "s": "請立刻返回起點", "p": [6] },
	{ "s": "請選擇它的外觀", "p": [11] }
];