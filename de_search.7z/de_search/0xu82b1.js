DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u82b1"] = [
	{ "s": "花朵等等生機勃勃物品的紋樣", "p": [11] }
];