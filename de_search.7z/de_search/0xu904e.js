DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u904e"] = [
	{ "s": "過度剝削可能導致它進入敵對狀態", "p": [6] },
	{ "s": "過往的戰士們將作爲強大的精魂徘徊於世", "p": [11] },
	{ "s": "過着勾心鬥角的生活", "p": [11] }
];