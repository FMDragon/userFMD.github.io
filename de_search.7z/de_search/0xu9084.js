DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9084"] = [
	{ "s": "還保存了一些來自王國滅亡前的機械零件", "p": [5] },
	{ "s": "還是小說", "p": [11] },
	{ "s": "還是所有儀式的核心", "p": [5] },
	{ "s": "還是病入膏肓", "p": [11] },
	{ "s": "還有的宗派則教導那些欲追名逐利的學徒在爲上位者服務時", "p": [11] }
];