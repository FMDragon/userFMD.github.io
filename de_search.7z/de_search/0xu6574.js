DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6574"] = [
	{ "s": "整個圖書館陷入幽暗之中", "p": [6] },
	{ "s": "整座圖書館由蜿蜒的書架組成", "p": [6] },
	{ "s": "整座圖書館由蜿蜒的書架組成，書架高聳入天花板，彷彿無窮無盡。中央有一座拱形天窗，白天時陽光能夠灑下柔和的光線，但到了夜晚，整個圖書館陷入幽暗之中", "p": [6] }
];