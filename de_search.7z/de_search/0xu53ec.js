DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53ec"] = [
	{ "s": "召喚出強大之力的精神化身", "p": [11] }
];