DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5c0b"] = [
	{ "s": "尋找廣闊無垠的海洋中潛藏的冒險與秘密的決心驅使著這些立下遠洋之誓的聖武士", "p": [11] }
];