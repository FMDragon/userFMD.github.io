DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7acb"] = [
	{ "s": "立下王冠之誓的聖武士們致力於服務社會", "p": [11] },
	{ "s": "立誓於懲罰那些犯下嚴重罪行之人", "p": [11] }
];