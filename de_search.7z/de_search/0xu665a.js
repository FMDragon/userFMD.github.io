DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u665a"] = [
	{ "s": "晚上是閉館時間", "p": [6] },
	{ "s": "晚上是閉館時間，請勿閱讀", "p": [6] }
];