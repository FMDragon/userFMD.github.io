DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7942"] = [
	{ "s": "祂們之中包括了閃電和雷霆之神", "p": [11] },
	{ "s": "祂們是竊賊", "p": [11] },
	{ "s": "祂們有些是掌管美麗和藝術的神祇", "p": [11] },
	{ "s": "祂們的牧師是顛覆世界的力量", "p": [11] },
	{ "s": "祂們的眼睛能穿透每一片陰影", "p": [11] }
];