DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5617"] = [
	{ "s": "嘗試從禁書中取得關鍵信息", "p": [6] }
];