DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u54c0"] = [
	{ "s": "哀傷和悲愴是和歡樂喜悅相同的強大情感", "p": [11] }
];