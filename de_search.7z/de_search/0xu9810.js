DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9810"] = [
	{ "s": "預言", "p": [11] },
	{ "s": "預言：不管是王室或平凡人家，大家都在尋求來自預言師的建議，因爲所有人都冀望能對過去、現在、和未來有更加深入的理解。作爲一名預言師，你致力於揭開時間、空間、和意識的神祕面紗以讓你能看得更清楚。你努力掌握那些與識別、遠視、超自然知識，和預知未來有關的法術", "p": [11] }
];