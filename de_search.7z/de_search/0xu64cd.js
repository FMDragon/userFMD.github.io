DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u64cd"] = [
	{ "s": "操作氣以治療他們身體所受的傷害", "p": [11] }
];