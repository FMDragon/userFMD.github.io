DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7531"] = [
	{ "s": "由於你出身平凡", "p": [9] },
	{ "s": "由於你的貴族出身", "p": [9] },
	{ "s": "由於你運行法律", "p": [9] }
];