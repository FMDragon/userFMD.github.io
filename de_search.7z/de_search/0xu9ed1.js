DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9ed1"] = [
	{ "s": "黑", "p": [10] },
	{ "s": "黑刃", "p": [11] },
	{ "s": "黑暗顯現的迷離境界中", "p": [11] }
];