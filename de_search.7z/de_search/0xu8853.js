DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8853"] = [
	{ "s": "術士", "p": [11] },
	{ "s": "術士們天生便具有能夠塑造和運用這些世界上的出格力量的能力", "p": [11] }
];