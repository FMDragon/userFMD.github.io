DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u737b"] = [
	{ "s": "獻身於救贖之誓的聖武士們相信任何人都可以得到救贖", "p": [11] }
];