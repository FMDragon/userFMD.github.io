DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5851"] = [
	{ "s": "塑能", "p": [11] },
	{ "s": "塑能：你專注於研究能創造出強大元素效果的魔法，諸如刺骨寒冷、熾熱火焰、轟隆雷鳴、躍動閃電、和燒灼強酸。有些塑能師會受僱於軍隊，成爲從遠方轟炸敵軍的砲臺。有些會用他們的壯闊法術保護弱者，也有些會爲了自己的利益而成爲盜匪、冒險者、或胸懷抱負的暴君", "p": [11] }
];