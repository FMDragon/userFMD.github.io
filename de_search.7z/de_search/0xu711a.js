DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u711a"] = [
	{ "s": "焚燒某樣事物卻又給予它者生命", "p": [11] }
];