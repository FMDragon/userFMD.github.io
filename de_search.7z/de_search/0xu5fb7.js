DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5fb7"] = [
	{ "s": "德魯伊", "p": [11] },
	{ "s": "德魯伊們從這些地點汲取生命力", "p": [11] }
];