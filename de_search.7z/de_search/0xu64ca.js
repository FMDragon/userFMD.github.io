DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u64ca"] = [
	{ "s": "擊穿阻礙他們的物理和心靈障礙", "p": [11] }
];