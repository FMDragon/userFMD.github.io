DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6df1"] = [
	{ "s": "深海", "p": [11] },
	{ "s": "深海：你已經浸沒於和深淵的契約。你現在可以汲取整個大洋，水元素位面或者其他的異界海洋的無盡力量。你的宗主僅僅是想利用你去了解陸地，或者它希望你打開深海的閥門去淹沒整個世界", "p": [11] }
];