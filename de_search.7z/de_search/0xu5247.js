DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5247"] = [
	{ "s": "則你可以從你神祇的神殿和其他宗教團體那裏獲得幫助", "p": [9] }
];