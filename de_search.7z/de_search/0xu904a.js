DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u904a"] = [
	{ "s": "遊俠", "p": [11] },
	{ "s": "遊蕩者", "p": [11] },
	{ "s": "遊蕩者的生活常常是日復一日的遊走在生死邊緣", "p": [11] }
];