DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7378"] = [
	{ "s": "獸王", "p": [11] },
	{ "s": "獸王範型體現了文明種族和自然野獸之間的情誼", "p": [11] },
	{ "s": "獸王：獸王範型體現了文明種族和自然野獸之間的情誼。團結一致，野獸和遊俠將共同對抗威脅着文明和自然世界的可怕敵人。仿效獸王範型意味着將自己奉獻給這個理念，與動物作爲同伴和朋友一同奮鬥", "p": [11] }
];