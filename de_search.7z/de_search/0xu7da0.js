DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7da0"] = [
	{ "s": "綠", "p": [10] },
	{ "s": "綠之騎士", "p": [11] }
];