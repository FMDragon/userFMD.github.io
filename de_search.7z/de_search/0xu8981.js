DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8981"] = [
	{ "s": "要求這名神聖戰士只能在最後關頭使用暴力", "p": [11] }
];