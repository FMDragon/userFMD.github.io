DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7d55"] = [
	{ "s": "絕大多數的刺客都用物理的武器襲擊", "p": [11] }
];