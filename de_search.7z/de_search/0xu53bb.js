DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53bb"] = [
	{ "s": "去搜尋哪怕最難分辨的一絲線索", "p": [9] }
];