DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u610f"] = [
	{ "s": "意圖以古老的力量保留王國的希望", "p": [3] },
	{ "s": "意爲", "p": [11] }
];