DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5e73"] = [
	{ "s": "平民盡他所可能遷就你並避免惹惱你", "p": [9] },
	{ "s": "平民英雄", "p": [9] },
	{ "s": "平民英雄：由於你出身平凡，因此能輕易融入平民之中。除非你讓他們覺得你是個危害，否則你將可以在民間找到休息或藏身的居所。他們會庇護你，助你躲避執法者或其他人的搜索，然而他們並不會爲你賭上性命", "p": [9] }
];