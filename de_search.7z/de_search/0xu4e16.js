DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4e16"] = [
	{ "s": "世界並非一成不變", "p": [11] },
	{ "s": "世界概述", "p": [3] }
];