DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u53e4"] = [
	{ "s": "古木", "p": [11] },
	{ "s": "古老的恐怖之物留下的污染還是德魯伊自身犯下的可怕錯誤", "p": [11] },
	{ "s": "古老知識的探索", "p": [6] }
];