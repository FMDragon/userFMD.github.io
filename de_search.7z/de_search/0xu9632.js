DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9632"] = [
	{ "s": "防護", "p": [11] },
	{ "s": "防護學派強調着阻擋", "p": [11] },
	{ "s": "防護：防護學派強調着阻擋、驅逐、或守護的魔法。詆譭這個學派的人們宣稱它的傳統充滿着否認和拒絕，而非肯定。然而，你明白終止有害效果、守護弱小、並驅逐邪惡的影響絕非虛無的哲學。這是一份值得驕傲且受人尊敬的使命", "p": [11] }
];