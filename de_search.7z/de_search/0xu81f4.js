DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u81f4"] = [
	{ "s": "致力於蠱惑暴力者使之放下武器", "p": [11] }
];