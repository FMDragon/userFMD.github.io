DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8ca0"] = [
	{ "s": "負責驅趕謊言並燃盡黑暗", "p": [11] }
];