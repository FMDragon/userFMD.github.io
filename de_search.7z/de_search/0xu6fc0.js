DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6fc0"] = [
	{ "s": "激勵他人在戰鬥中打一場好仗", "p": [11] },
	{ "s": "激起毀滅與創造", "p": [11] }
];