DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8272"] = [
	{ "s": "色彩龍裔", "p": [10] },
	{ "s": "色彩龍裔【紅、藍、綠、黑、白", "p": [10] }
];