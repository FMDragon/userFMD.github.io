DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u52a9"] = [
	{ "s": "助你躲避執法者或其他人的搜索", "p": [9] }
];