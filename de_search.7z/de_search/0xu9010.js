DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u9010"] = [
	{ "s": "逐漸將這片土地拖入深淵", "p": [3] }
];