DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4ee3"] = [
	{ "s": "代表你的天生魔法可能來自一個與某種神性存在有所聯繫", "p": [11] }
];