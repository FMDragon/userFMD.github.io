DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7cbe"] = [
	{ "s": "精靈", "p": [10] },
	{ "s": "精類", "p": [11] },
	{ "s": "精魄能化形為龍獸", "p": [11] }
];