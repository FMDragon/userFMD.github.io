DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u90fd"] = [
	{ "s": "都可能讓一片土地被魔法所詛咒", "p": [11] },
	{ "s": "都會將這伴隨歌詠之劍的壯麗舞蹈當作人生中最爲美妙的經歷之一銘記於心", "p": [11] },
	{ "s": "都能聽到其嫋嫋不絕的迴音", "p": [11] }
];