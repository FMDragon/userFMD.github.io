DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5730"] = [
	{ "s": "地板由暗紅色的石塊鋪設", "p": [6] },
	{ "s": "地板由暗紅色的石塊鋪設，踩在上面時，會有微弱的回音，彷彿腳下的石頭也在低聲訴說什麼", "p": [6] },
	{ "s": "地表深處", "p": [11] },
	{ "s": "地震之神", "p": [11] }
];