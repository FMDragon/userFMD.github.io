DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6240"] = [
	{ "s": "所以一位吟遊詩人不一定能完全掌控其召喚出來的靈魂", "p": [11] },
	{ "s": "所有的凡人生物都能在抬頭仰望天空時看到艾桑椎亞的兩顆月亮", "p": [11] },
	{ "s": "所有野蠻人的體內都懷着狂怒", "p": [11] }
];