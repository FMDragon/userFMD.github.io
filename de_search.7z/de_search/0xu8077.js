DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8077"] = [
	{ "s": "職業", "p": [11] },
	{ "s": "職業特殊改動", "p": [12] }
];