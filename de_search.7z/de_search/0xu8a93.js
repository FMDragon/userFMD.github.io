DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u8a93"] = [
	{ "s": "誓言將他們技藝與任務隱藏於黑暗中", "p": [11] }
];