DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u80cc"] = [
	{ "s": "背景", "p": [9] },
	{ "s": "背景世界觀", "p": [2] },
	{ "s": "背景設定", "p": [4] },
	{ "s": "背誦那些早已被遺忘的禱詞", "p": [11] }
];