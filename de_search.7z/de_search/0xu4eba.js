DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u4eba"] = [
	{ "s": "人們將其看做墮落行為和厄運的徵兆", "p": [11] },
	{ "s": "人們會傾向記住你最好的一面", "p": [9] },
	{ "s": "人們結束了白天的工作並開始休息", "p": [11] },
	{ "s": "人類", "p": [10] }
];