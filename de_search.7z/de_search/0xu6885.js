DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u6885"] = [
	{ "s": "梅菲斯托費勒斯之血", "p": [10] }
];