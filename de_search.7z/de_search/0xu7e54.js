DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u7e54"] = [
	{ "s": "織月者本身便在卡薩那淡淡的微光中指引的崇拜者", "p": [11] }
];