DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u5118"] = [
	{ "s": "儘管仍然存在這樣的特例", "p": [11] },
	{ "s": "儘管令人恐懼之物潛伏於黑暗之中", "p": [11] },
	{ "s": "儘管它的存在本身充滿了神秘", "p": [5] },
	{ "s": "儘管有些遊蕩者極力排斥", "p": [11] },
	{ "s": "儘管這樣的成果", "p": [11] }
];